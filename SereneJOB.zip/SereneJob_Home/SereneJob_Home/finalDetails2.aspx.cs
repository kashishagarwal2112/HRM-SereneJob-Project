﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


namespace SereneJob_Home
{
    public partial class finalDetails2 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD ;Initial Catalog= SereneJob;Integrated Security=True");
        public string emprid, empid;

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmp.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmpr.aspx");

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("AboutUs.aspx");

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("ContactUs.aspx");

        }

        protected void bttn_Click(object sender, EventArgs e)
        {
            con.Open();
            string a = "select workingHours,jobLocation,salaryDecided from [emprDetails] where userID='" + idtxt + "'";
            SqlCommand cmd1 = new SqlCommand(a, con);
            cmd1.ExecuteNonQuery();
            SqlDataReader read1 = cmd1.ExecuteReader();
            string loc = read1["workLocation"].ToString();
            
            string sal = read1["salaryExpected"].ToString();
            string qual = read1["qualification"].ToString();
            string wh = read1["workingHours"].ToString();

            string insert = "insert into [jobAvailable]([emprID],[empID],[timings],[location],[salary])" +
                " values('" + emprid + "','" + empid + "','" + wh + "','" + loc + "','" + sal + "')";

            read1.Close();
            con.Close();
            Response.Redirect("HomePage.aspx");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string q1 = "select e2.userID,e1.empID,e2.emprID from [empDetails] e1,[emprDetails] e2 where e1.[requiredField]=e2.[requirementField] ";
            SqlCommand cmd = new SqlCommand(q1, con);
            con.Open();
            SqlDataReader read = cmd.ExecuteReader();
            string id = read["userID"].ToString();
            emprid = read["emprID"].ToString();
            empid = read["empID"].ToString();
            read.Close();

            string details = "select firstname,lastname,workLocation,salaryExpected,qualification,workingHours,experience from emprDetails where userID ='" + Convert.ToInt32(id) + "'";

            SqlCommand cmd2 = new SqlCommand(details, con);
            SqlDataReader read2 = cmd2.ExecuteReader();
            string name = read2["firstname"].ToString();
            string name2 = read2["lastname"].ToString();
            string loc = read2["workLocation"].ToString();
            string exp = read2["experience"].ToString();
            string sal = read2["salaryExpected"].ToString();
            string qual = read2["qualification"].ToString();
            string wh = read2["workingHours"].ToString();

            det.Text = "NAME: '" + name + "' '" + name2 + "' \nJOB LOCATION: '" + loc + "'\nEXPERIENCE: '" + exp + "'\nSALARY: '" + sal + "'\nQUALIFICATION WANTED: '" + qual + "'\nWORKING HOURS: '" + wh + "'\n";
            bttn1.Enabled = true;
            read2.Close();
            con.Close();
            

        }
    }
}