﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace SereneJob_Home
{

    public partial class forgetPassword : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD ;Initial Catalog= SereneJob;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string q = "update [register] set password='" + p1.Text + "'";

            if (p1.Text == p2.Text)
            {
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.ExecuteNonQuery();
                SqlDataReader read = cmd.ExecuteReader();
                Response.Redirect("LoginPage.aspx");
            }
            else
                lbltxt.Text = "Enter Same Password.";
        }
    }
}