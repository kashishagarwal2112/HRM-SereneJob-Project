﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace SereneJob_Home
{
    public partial class ListEmpr : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD ;Initial Catalog= SereneJob;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

            //string q1 = "select e2.userID from [empDetails] e1,[emprDetails] e2 where e1.[requiredField]=e2.[requirementField] ";
            //con.Open();
            //SqlCommand cmd = new SqlCommand("userid", con);
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.ExecuteNonQuery();

            //SqlDataReader read = cmd.ExecuteReader();
            //if (!read.HasRows)
            //{
            //    while (read.Read())
            //    {

            //        int id = Convert.ToInt32(read["userID"]);

            //        string details = "select jobLocation,salaryDecided,qualificationWanted,workingHours,experienceWanted from emprDetails where userID ='" + id + "'";
            //        string namedetails = "select firstName,lastName from [register] where userID = '" + id + "'";
            //        SqlCommand cmd2 = new SqlCommand(details, con);

            //        read.Close();
            //        SqlCommand cmd3 = new SqlCommand(namedetails, con);
            //        SqlDataReader read2 = cmd2.ExecuteReader();

            //        if (read2.HasRows)
            //        {
            //            while (read2.Read())
            //            {

            //                string loc = read2[0].ToString();
            //                string exp = read2[1].ToString();
            //                string sal = read2[2].ToString();
            //                string qual = read2[3].ToString();
            //                string wh = read2[4].ToString();
            //                read2.Close();

            //                SqlDataReader read3 = cmd3.ExecuteReader();
            //                string name = read3[0].ToString();
            //                string name2 = read3[1].ToString();

            //                listtxt.Text = "NAME: '" + name + "' '" + name2 + "' \nJOB LOCATION: '" + loc + "'\nEXPERIENCE: '" + exp + "'\nSALARY: '" + sal + "'\nQUALIFICATION WANTED: '" + qual + "'\nWORKING HOURS: '" + wh + "'\n";


            //                read3.Close();

            //            }

            //        }





            //    }
            //    con.Close();

            //}else
            listtxt.Text = "Sorry no Data found. we will inform you when we found a suitable job for you.thanks!";

        }

                   

        protected void bttn_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage2.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmpr.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmp.aspx");

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("AboutUs.aspx");

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("ContactUs.aspx");

        }
    }
}