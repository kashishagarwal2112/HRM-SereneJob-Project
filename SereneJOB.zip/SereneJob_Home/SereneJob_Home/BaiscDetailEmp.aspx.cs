﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace SereneJob_Home
{
    public partial class BaiscDetailEmp : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD;Initial Catalog= SereneJob;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string ins = "Insert into [EmpDetails]([requiredField],[qualification],[experience],[salaryExpected],[currentLocation],[workLocation],[rangeArea],[workingHours],[userID]) " +
                "values('" + DropDownList1.SelectedValue + "','" + qualtxt.Text + "','" + exptxt.Text + "','" + saltxt.Text + "','" + curloctxt.Text + "','" + workloctxt.Text + "','" + rangetxt.Text + "','" + timetxt.Text + "','" + useridtxt + "')";

            Response.Redirect("PersonalEmpDetails.aspx");
        }
    }
}