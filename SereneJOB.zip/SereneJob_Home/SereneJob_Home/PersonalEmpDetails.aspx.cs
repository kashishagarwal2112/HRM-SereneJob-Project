﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace SereneJob_Home
{
    public partial class PersonalEmpDetails : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD;Initial Catalog= SereneJob;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                dobtxt.Visible = false;
            }
        }
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            //string inst = "Insert into [empPersonalDetails]([permanentAddress],[presentAddress],[gender],[dob],[nationality],[userId]) values('" + permaddtxt.Text + "','" + preaddtxt.Text + "','" + RadioButtonList1.SelectedItem.Text + "','" + dob.Text+ "','" + nttxt.Text + "','" + usridtxt.Text + "')";
            //SqlCommand cmd = new SqlCommand(inst, con);
            //con.Open();
            //cmd.ExecuteNonQuery();
            //con.Close();
            Response.Redirect("ListEmpr.aspx");
        }

        protected void dobtxt_SelectionChanged(object sender, EventArgs e)
        {
            dob.Text = dobtxt.SelectedDate.ToString("dd/MM/yyyy");
            
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (dobtxt.Visible)
            {
                dobtxt.Visible = false;
            }
            else
            {
                dobtxt.Visible = true;
            }
            dobtxt.Attributes.Add("style", "position:absolute");
        }

        protected void usridtxt_TextChanged(object sender, EventArgs e)
        {

        }

    }
}