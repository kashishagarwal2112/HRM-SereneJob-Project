﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace SereneJob_Home
{
    public partial class BasicDetailEmpr : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD;Initial Catalog= SereneJob;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        

        protected void Button1_Click(object sender, EventArgs e)
        {
            string ins = "Insert into [emprDetails]([requirementField],[qualificationWanted],[experienceWanted],[salaryDecided],[jobLocation],[workingHours],[userID]) values('" + DropDownList1.SelectedValue + "','" + qualtxt.Text + "','" + Convert.ToInt32(exptxt.Text) + "','" + Convert.ToInt32(saltxt.Text) + "','" + loctxt.Text + "','" + Convert.ToInt32(timetxt.Text) + "','" + Convert.ToInt32(useridtxt.Text) + "')";
            
                Response.Redirect("PersonalEmprDetails.aspx");
            
        }
    }
}