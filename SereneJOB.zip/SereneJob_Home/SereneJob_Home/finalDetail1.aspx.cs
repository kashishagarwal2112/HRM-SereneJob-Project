﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace SereneJob_Home
{
    public partial class finalDetail1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD ;Initial Catalog= SereneJob;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            string q1 = "select e2.userID from [empDetails] e1,[emprDetails] e2 where e1.requiredField=e2.requirementField ";
            SqlCommand cmd = new SqlCommand(q1, con);
            con.Open();
            SqlDataReader read = cmd.ExecuteReader();

            string id = read["empID"].ToString();
            read.Close();
            string details = "select firstname,jobLocation,salaryDecided,qualificationWanted,workingHours from empDetails where userID ='" + Convert.ToInt32(id) + "'";
            string phone = "select phoneNo from register  where userID ='" + Convert.ToInt32(id) + "'";
            SqlCommand cmd2 = new SqlCommand(details, con);
            SqlDataReader read2 = cmd2.ExecuteReader();
            SqlCommand cmd3 = new SqlCommand(phone, con);
            SqlDataReader read3 = cmd3.ExecuteReader();
            if (read2.HasRows)
            {
                while (read2.Read())
                {
                    string name = read2["firstname"].ToString();

                    string loc = read2["jobLocation"].ToString();
                    string phn = read3["phoneNo"].ToString();
                    string sal = read2["salaryDecided"].ToString();
                    string qual = read2["qualificationWanted"].ToString();
                    string wh = read2["workingHours"].ToString();

                    det.Text = "NAME: '" + name + "' PHONE NO: '" + phn + "'\nJOB LOCATION: '" + loc + "'\nSALARY: '" + sal + "'\nQUALIFICATION WANTED: '" + qual + "'\nWORKING HOURS: '" + wh + "'\n";
                    bttn1.Enabled = true;
                    read2.Close();


                }

            }
        }

        protected void bttn_Click(object sender, EventArgs e)
        {
            SqlCommand q1 = new SqlCommand("select empID from empDetails where userID='"+id+"'");
            q2=new SqlCommand("")
            string query = "insert into [jobAvailable]([jobName],[salary],[location],[empID],[emprID]) values()";
            SqlCommand insert = new SqlCommand();
        }
    }
}