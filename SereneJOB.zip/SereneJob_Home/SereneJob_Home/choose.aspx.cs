﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SereneJob_Home
{
    public partial class choose : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (RadioButtonList1.SelectedIndex==0)
            {
                Response.Redirect("BaiscDetailEmp.aspx");
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                Response.Redirect("BasicDetailEmpr.aspx");
            }
            else
                Label2.Text="Plaese choose an option";
                
        }
        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

    }
}