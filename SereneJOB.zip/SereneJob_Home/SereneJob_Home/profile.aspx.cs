﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Razor;

namespace SereneJob_Home
{
    public partial class profile : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD;Initial Catalog= SereneJob;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            getuserdetails();
        }

        protected void getuserdetails()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from EmpDetails", con);
            SqlDataReader read = cmd.ExecuteReader();
            while (read.Read())
            {
                jobtxt.Text = read["requiredField"].ToString();
                quatxt.Text = read["qualification"].ToString();
                exptxt.Text = read["experience"].ToString();
                saltxt.Text = read["salaryExpected"].ToString();
                lctntxt.Text = read["CurrentLocation"].ToString();
                wrktxt.Text = read["workLocation"].ToString();
                kmtxt.Text = read["rangeArea"].ToString();
                hrtxt.Text = read["workingHours"].ToString();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}