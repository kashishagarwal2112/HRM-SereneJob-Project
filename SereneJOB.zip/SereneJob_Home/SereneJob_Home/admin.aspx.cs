﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;


namespace SereneJob_Home
{

    public partial class admin : System.Web.UI.Page
    {
        public string mycon = "Data Source=DESKTOP-PPG4BOD;Initial Catalog= SereneJob;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = SqlDataSource1;
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
            Label8.Text = "";
            GridView1.EditRowStyle.BackColor = System.Drawing.Color.Orange;

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

            GridView1.EditIndex = -1;
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
            Label8.Text = "";

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            Label rollno = GridView1.Rows[e.RowIndex].FindControl("Label7") as Label;
            TextBox sname = GridView1.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;
            TextBox fathername = GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;
            TextBox mothername = GridView1.Rows[e.RowIndex].FindControl("TextBox3") as TextBox;
            //String mycon = "Data Source=HP-PC\\SQLEXPRESS; Initial Catalog=CollegeData; Integrated Security=True";
            String updatedata = "Update studentdata set sname='" + sname.Text + "', fathername='" + fathername.Text + "', mothername='" + mothername.Text + "' where rollno=" + rollno.Text;
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Label8.Text = "Row Data Has Been Updated Successfully";
            GridView1.EditIndex = -1;
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();

        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {

            TextBox rollno = GridView1.FooterRow.FindControl("TextBox4") as TextBox;
            TextBox sname = GridView1.FooterRow.FindControl("TextBox5") as TextBox;
            TextBox fathername = GridView1.FooterRow.FindControl("TextBox6") as TextBox;
            TextBox mothername = GridView1.FooterRow.FindControl("TextBox7") as TextBox;
            String query = "insert into register(userID,firstName,lastName,phoneNo,emailID,password) values(" + rollno.Text + ",'" + sname.Text + "','" + fathername.Text + "','" + mothername.Text + "')";
            //String mycon = "Data Source=HP-PC\\SQLEXPRESS; Initial Catalog=CollegeData; Integrated Security=true";
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = query;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Label8.Text = "New Row Inserted Successfully";
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label rollno = GridView1.Rows[e.RowIndex].FindControl("Label1") as Label;
           // String mycon = "Data Source=HP-PC\\SQLEXPRESS; Initial Catalog=CollegeData; Integrated Security=True";
            String updatedata = "delete from register where userID=" + rollno.Text;
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Label8.Text = "Row Data Has Been Deleted Successfully";
            GridView1.EditIndex = -1;
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmp.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmpr.aspx");

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("AboutUs.aspx");

        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("ContactUs.aspx");

        }
    }

}