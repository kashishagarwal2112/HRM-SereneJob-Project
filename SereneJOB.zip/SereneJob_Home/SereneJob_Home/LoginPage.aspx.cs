﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace SereneJob_Home
{
    public partial class LoginPage : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PPG4BOD;Initial Catalog= SereneJob;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        

        protected void Button1_Click1(object sender, EventArgs e)
        {
            string check = "select count(*) from [register] where emailID ='" + usertxt.Text + "' and [Password] ='" + passtxt.Text + "' ";
            SqlCommand cmd = new SqlCommand(check, con);
            con.Open();
            int temp = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();

            if (DropDownList1.SelectedValue == "0")
            {
                Response.Redirect("admin.aspx");
            }
            else
            {
                if (temp == 1)
                {
                    Response.Redirect("HomePage2.aspx");

                }
                else
                {
                    Label5.ForeColor = System.Drawing.Color.Red;
                    Label5.Text = "Your email-id or password is invalid.";
                }
            }
        }

        protected void passtxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}